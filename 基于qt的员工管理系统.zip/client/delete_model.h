#ifndef DELETE_MODEL_H
#define DELETE_MODEL_H

#include <QDialog>
#include<QTcpSocket>
#include<QTcpServer>
#include <QWidget>
#include <QMessageBox>
namespace Ui {
class delete_model;
}

class delete_model : public QDialog
{
    Q_OBJECT

public:
    explicit delete_model(QWidget *parent = 0,QTcpSocket * s = 0 );
    ~delete_model();

private slots:
    void on_pushButton_clicked();
    void read_data();

private:
    Ui::delete_model *ui;
    QTcpSocket * socket;
};

#endif // DELETE_MODEL_H
