#ifndef MAIN_MODEL_H
#define MAIN_MODEL_H

#include <QDialog>
#include<QTcpSocket>
#include<QTcpServer>
#include <QWidget>
#include <QMessageBox>
#include "delete_model.h"
#include "insert_model.h"
#include "select_model.h"
#include "update_model.h"
namespace Ui {
class main_model;
}

class main_model : public QDialog
{
    Q_OBJECT

public:
    explicit main_model(QWidget *parent = 0,QTcpSocket * s = 0);
    ~main_model();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::main_model *ui;
    QTcpSocket * socket;
    delete_model *p_delete = 0;
    insert_model *p_insert = 0;
    select_model *p_select = 0;
    update_model *p_update = 0;
};

#endif // MAIN_MODEL_H
