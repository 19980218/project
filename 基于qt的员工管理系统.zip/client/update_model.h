#ifndef UPDATE_MODEL_H
#define UPDATE_MODEL_H

#include <QDialog>
#include<QTcpSocket>
#include<QTcpServer>
#include <QWidget>
#include <QMessageBox>
namespace Ui {
class update_model;
}

class update_model : public QDialog
{
    Q_OBJECT

public:
    explicit update_model(QWidget *parent = 0,QTcpSocket * s = 0);
    ~update_model();

private slots:
    void on_pushButton_clicked();
    void read_date();

private:
    Ui::update_model *ui;
    QTcpSocket * socket;
};

#endif // UPDATE_MODEL_H
