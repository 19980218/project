#ifndef SELECT_MODEL_H
#define SELECT_MODEL_H

#include <QDialog>
#include<QTcpSocket>
#include<QTcpServer>
#include <QWidget>
#include <QMessageBox>
namespace Ui {
class select_model;
}

class select_model : public QDialog
{
    Q_OBJECT

public:
    explicit select_model(QWidget *parent = 0,QTcpSocket * s = 0);
    ~select_model();

private slots:
    void on_pushButton_clicked();
    void read_data();

private:
    Ui::select_model *ui;
    QTcpSocket * socket;
};

#endif // SELECT_MODEL_H
