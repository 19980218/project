#include "select_model.h"
#include "ui_select_model.h"
#include <QDialog>
#include<QTcpSocket>
#include<QTcpServer>
#include <QWidget>
#include <QMessageBox>

select_model::select_model(QWidget *parent,QTcpSocket * s) :
    QDialog(parent),socket(s),
    ui(new Ui::select_model)
{
    ui->setupUi(this);
    connect(socket, &QTcpSocket::readyRead, this,&select_model::read_data );
}

select_model::~select_model()
{
    delete ui;
}

void select_model::on_pushButton_clicked()
{
    if (ui->lineEdit->text() == "" || ui->lineEdit_2->text() == "")
    {
        QMessageBox::information(this,"px","请输入完整信息");
    }
    else
    {
        QString temp ;
        temp = "#'" + ui->lineEdit->text() + "','" + ui->lineEdit_2->text() + "'";
        QByteArray bytes = temp.toUtf8();
        socket->write(bytes);
        ui->lineEdit->setText("");
        ui->lineEdit_2->setText("");
        ui->textEdit->setText("");
    }
}
void select_model::read_data()
{
    QString str;
    QByteArray buffer = socket->readAll();
    str.prepend(buffer);
    qDebug() << str;
    if (str == "no!")
    {
        QMessageBox::information(this,"px","没有此员工!");
    }
    else
    {
        ui->textEdit->setText(str);
    }
}
