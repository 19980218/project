#ifndef INSERT_MODEL_H
#define INSERT_MODEL_H

#include <QDialog>
#include<QTcpSocket>
#include<QTcpServer>
#include <QWidget>
#include <QMessageBox>
namespace Ui {
class insert_model;
}

class insert_model : public QDialog
{
    Q_OBJECT

public:
    explicit insert_model(QWidget *parent = 0,QTcpSocket * s = 0);
    ~insert_model();

private slots:
    void on_pushButton_clicked();
    void read_data();

private:
    Ui::insert_model *ui;
    QTcpSocket * socket;
};

#endif // INSERT_MODEL_H
