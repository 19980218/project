#include "update_model.h"
#include "ui_update_model.h"
#include <QDialog>
#include<QTcpSocket>
#include<QTcpServer>
#include <QWidget>
#include <QMessageBox>
update_model::update_model(QWidget *parent,QTcpSocket * s) :
    QDialog(parent),socket(s),
    ui(new Ui::update_model)
{
    ui->setupUi(this);
    connect(socket, &QTcpSocket::readyRead, this,&update_model::read_date );
}

update_model::~update_model()
{
    delete ui;
}

void update_model::on_pushButton_clicked()
{
    if (ui->lineEdit->text() == "" || ui->lineEdit_2->text() == "")
    {
        QMessageBox::information(this,"px","员工号或姓名不能为空！");
    }
    else
    {
        QString temp ;
        temp = "$'"+ui->lineEdit->text()+"','"+ui->lineEdit_2->text()+"','"+ui->lineEdit_3->text()+"','"+ui->lineEdit_4->text()+"','"+ui->lineEdit_5->text()+"','"+ui->lineEdit_6->text()+"','"+ui->lineEdit_7->text()+"','"+ui->lineEdit_8->text()+"','"+ui->lineEdit_9->text()+"'";
        QByteArray bytes = temp.toUtf8();
        socket->write(bytes);
        ui->lineEdit->setText("");
        ui->lineEdit_2->setText("");
        ui->lineEdit_3->setText("");
        ui->lineEdit_4->setText("");
        ui->lineEdit_5->setText("");
        ui->lineEdit_6->setText("");
        ui->lineEdit_7->setText("");
        ui->lineEdit_8->setText("");
        ui->lineEdit_9->setText("");
    }
}
void update_model::read_date()
{
    QString str;
    QByteArray buffer = socket->readAll();
    str.prepend(buffer);
    qDebug() << str;
    if (str == "no_user!")
    {
        QMessageBox::information(this,"px","没有此用户！");
    }
    else if (str == "no_dp!")
    {
        QMessageBox::information(this,"px","没有此部门！");
    }
    else if (str == "no_po!")
    {
        QMessageBox::information(this,"px","没有此职位！");
    }
    else if (str == "yes!")
    {
        QMessageBox::information(this,"px","更新成功！");
    }
    else if (str == "no!")
    {
        QMessageBox::information(this,"px","更新失败！");
    }

}
