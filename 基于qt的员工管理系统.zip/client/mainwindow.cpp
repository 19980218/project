#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QTcpSocket>
#include<QTcpServer>
#include <QWidget>
#include <QMessageBox>
#include "main_model.h"
#include <qDebug>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    blockSize = 0;


}
MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::read_data()
{
    if (blockSize == 1)
    {
        return;
    }
    QString str;
    QByteArray buffer = tcpSocket->readAll();
    str.prepend(buffer);
    qDebug() << str;
    if (str == "yes!")
    {
        blockSize = 1;
        QMessageBox::information(this,"px","登陆成功!");

    }
    else
    {
        QMessageBox::information(this,"px","查无此用户!");
    }


}
void MainWindow::init_read_data()
{

}

void MainWindow::on_pushButton_clicked()//此函数初始化套接字，并且和服务器端连接
{

    tcpSocket = new QTcpSocket(this);
    connect(tcpSocket, &QTcpSocket::readyRead, this,&MainWindow::read_data );

    tcpSocket->connectToHost("127.0.0.1",6666);
    if(!tcpSocket->waitForConnected())
    {
       QMessageBox::information(this,"px","errror");
    }
    QString temp;
    temp = ui->lineEdit->text();
    temp = temp +"~" + ui->lineEdit_2->text();
    QByteArray bytes = temp.toUtf8();
    tcpSocket->write(bytes);
    /*if (blockSize == 1)
    {
        p = new main_model(this,tcpSocket) ;
        //disconnect(tcpSocket, 0, 0, 0);
        p->exec();
    }
    else
    {
        QMessageBox::information(this,"px","查无此人");
    }*/

        //emit init();
    //disconnect(tcpSocket, SIGNAL(init()), 0, 0);

}

void MainWindow::on_pushButton_2_clicked()
{
    ui->lineEdit->setText(" ");
    ui->lineEdit_2->setText(" ");
}

void MainWindow::on_pushButton_3_clicked()
{
        if (blockSize == 1)
        {
            p = new main_model(this,tcpSocket) ;
            //disconnect(tcpSocket, 0, 0, 0);
            p->exec();
            blockSize = 0;
            tcpSocket->write("~");
            delete p;
        }
        else
        {
            QMessageBox::information(this,"px","请先进行登录！");
        }
}
