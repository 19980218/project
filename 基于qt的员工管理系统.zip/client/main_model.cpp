#include "main_model.h"
#include "ui_main_model.h"
#include<QTcpSocket>
#include<QTcpServer>
#include <QWidget>
#include <QMessageBox>
main_model::main_model(QWidget *parent,QTcpSocket * s) :
    QDialog(parent),socket(s),
    ui(new Ui::main_model)
{

    ui->setupUi(this);
}

main_model::~main_model()
{
    delete ui;
}

void main_model::on_pushButton_2_clicked()
{
   p_delete = new delete_model(this,socket);
   p_delete->exec();
   delete p_delete;
}

void main_model::on_pushButton_clicked()
{
    p_insert= new insert_model(this,socket);
    p_insert->exec();
    delete p_insert;
}

void main_model::on_pushButton_3_clicked()
{
    p_select=new select_model(this,socket);
    p_select->exec();
    delete p_select;
}

void main_model::on_pushButton_4_clicked()
{
    p_update = new update_model(this,socket);
    p_update->exec();
    delete p_update;
}
