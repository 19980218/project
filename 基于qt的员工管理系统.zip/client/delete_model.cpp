#include "delete_model.h"
#include "ui_delete_model.h"
#include<QTcpSocket>
#include<QTcpServer>
#include <QWidget>
#include <QMessageBox>
delete_model::delete_model(QWidget *parent, QTcpSocket *  s) :
    QDialog(parent),socket(s),
    ui(new Ui::delete_model)
{
    ui->setupUi(this);

    connect(socket, &QTcpSocket::readyRead, this,&delete_model::read_data );
}

delete_model::~delete_model()
{
    delete ui;
}

void delete_model::on_pushButton_clicked()
{

    if (ui->lineEdit->text() == "" || ui->lineEdit_2->text() == "")
    {
        QMessageBox::information(this,"px","请输入完整的信息");
    }
    else
    {
        QString temp;
        temp = ui->lineEdit->text();
        temp = "@" + temp +"~" + ui->lineEdit_2->text();
        QByteArray bytes = temp.toUtf8();
        socket->write(bytes);
        ui->lineEdit->setText("");
        ui->lineEdit_2->setText("");
    }

}
void delete_model::read_data()
{
    QString str;
    QByteArray buffer = socket->readAll();
    str.prepend(buffer);
    qDebug() << str;
    if (str == "yes!")
    {

        QMessageBox::information(this,"px","删除成功!");

    }
    else if (str == "no_user!")
    {
        QMessageBox::information(this,"px","没有这个用户!");
    }
    else
    {
        QMessageBox::information(this,"px","删除失败!");
    }
}
