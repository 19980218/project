#include "insert_model.h"
#include "ui_insert_model.h"
#include <QDialog>
#include<QTcpSocket>
#include<QTcpServer>
#include <QWidget>
#include <QMessageBox>
insert_model::insert_model(QWidget *parent,QTcpSocket * s) :
    QDialog(parent),socket(s),
    ui(new Ui::insert_model)
{
    ui->setupUi(this);
     connect(socket, &QTcpSocket::readyRead, this,&insert_model::read_data );
}

insert_model::~insert_model()
{
    delete ui;
}

void insert_model::on_pushButton_clicked()
{
    if (ui->lineEdit->text() == "" || ui->lineEdit_2->text() == "")
    {
       QMessageBox::information(this,"px","员工号或者姓名不能为空！");
    }
    else
    {
        //socket->write("charu");
        QString temp ;
        temp ="!'"+ui->lineEdit->text()+"','"+ui->lineEdit_2->text()+"','"+ui->lineEdit_3->text()+"','"+ui->lineEdit_4->text()+"','"+ui->lineEdit_5->text()+"','"+ui->lineEdit_6->text()+"','"+ui->lineEdit_7->text()+"'";
        QByteArray bytes = temp.toUtf8();
        socket->write(bytes);
        ui->lineEdit->setText("");
        ui->lineEdit_2->setText("");
        ui->lineEdit_3->setText("");
        ui->lineEdit_4->setText("");
        ui->lineEdit_5->setText("");
        ui->lineEdit_6->setText("");
        ui->lineEdit_7->setText("");

    }

}
void insert_model::read_data()
{
    QString str;
    QByteArray buffer = socket->readAll();
    str.prepend(buffer);
    qDebug() << str;
    if (str == "yes!")
    {

        QMessageBox::information(this,"px","插入成功!");

    }
    else if (str == "no_department!")
    {
        QMessageBox::information(this,"px","没有此部门!");
    }
    else if (str == "no_position!")
    {
        QMessageBox::information(this,"px","没有此职位!");
    }
    else
    {
        QMessageBox::information(this,"px","插入失败!");
    }
}
