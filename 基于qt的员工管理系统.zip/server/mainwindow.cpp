#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QTcpSocket>
#include<QTcpServer>
#include <QWidget>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <qDebug>
#include <QStringList>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    tcpServer = new QTcpServer(this);
    // 使用了IPv4的本地主机地址，等价于QHostAddress("127.0.0.1")
    if (!tcpServer->listen(QHostAddress::LocalHost, 6666)) {
        qDebug() << tcpServer->errorString();
        close();
    }
    connect(tcpServer, &QTcpServer::newConnection, this,MainWindow::init);

    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("127.0.0.1");
    db.setDatabaseName("company_employees");
    db.setUserName("root");
    db.setPassword("px19980218");
    bool ok = db.open();

    if (ok == false)
    {
       QMessageBox::information(this,"px","打开数据库失败！");
    }

}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::init()//此函数进行对客户端的监听
{

   clientConnection = tcpServer->nextPendingConnection();
   connect(clientConnection, &QTcpSocket::readyRead, this,MainWindow::read_data1 );
   connect(clientConnection, &QTcpSocket::readyRead, this,MainWindow::read_data );


}
void MainWindow::read_data()
{
    if (flag == 0)
    {
        return ;
    }
    QString str;
    QByteArray buffer = clientConnection->readAll();
    str.prepend(buffer);
    if (str == "~")///代表用户退出登录界面
    {
        flag = 0;
        qDebug() << "flag=" << flag;
        return ;
    }
    else if (str[0] == '!')///代表用户进行插入操作
    {
        QSqlQuery query;
        QString temp = str.right(str.size()-1);
        QStringList all = temp.split(',');

        query.exec("select dp_id from department where dp_name=" + all[4] + ";");
        //qDebug() << "select dp_id from department where dp_name=" + all[4];
        if (query.next() == false)
        {
            clientConnection->write("no_department!");
            return;
        }
        QString dp_id = query.value(0).toString();
        query.exec("select po_id from position where po_name=" + all[5]+ ";");
        //qDebug() << "select po_id from position where po_name=" + all[5];
        if (query.next() == false)
        {
            clientConnection->write("no_position!");
            return;
        }
        QString po_id = query.value(0).toString();

        temp = "insert into employees(em_id,em_name,em_age,em_sex,dp_id,po_id,em_info) " +QString("values(" + all[0]+","+all[1]+","+all[2]+",  "+all[3]+","+dp_id+","+po_id+","+all[6]+ ");");
        qDebug() << temp;

        if (query.exec(temp))
        {
            clientConnection->write("yes!");
        }
        else
        {
            clientConnection->write("no!");
        }
    }
    else if (str[0] == '@')///代表用户进行删除操作
    {
        str = str.right(str.size()-1);
        qDebug() << str;
        int position = str.indexOf('~');
        QString left = str.left(position);
        QString right = str.right(str.size()-left.size()-1);
        str = "select * from employees " + QString("where") + " em_id='" + left +QString("'") + " and em_name='" + right+QString("';");
        QSqlQuery query;
        query.exec(str);
        if(query.next() == false)
        {
            clientConnection->write("no_user!");
            return ;
            //qDebug() << "yes!" << "flag=" << flag;
        }
        str = "delete from employees " + QString("where") + " em_id='" + left +QString("'") + " and em_name='" + right+QString("';");
        qDebug() << str;


        if (query.exec(str) == true)
        {
           clientConnection->write("yes!");
        }
        else
        {

           clientConnection->write("no!");
        }

    }
    else if (str[0] == '#')///代表用户进行查询操作
    {
        str = str.right(str.size()-1);
        qDebug() << str;
        QStringList all = str.split(',');
        str = "select employees.em_id,employees.em_name,employees.em_age,employees.em_sex,department.dp_name,position.po_name,employees.em_info from employees,department,position where employees.dp_id=department.dp_id and employees.po_id=position.po_id and employees.em_id=" + all[0] +" and employees.em_name="+all[1]+";";
        qDebug() << str;
        QSqlQuery query;
        query.exec(str);
        if (query.next() == false)
        {
            clientConnection->write("no!");
        }
        else
        {

            QString temp ;
            temp = "员工号:"+query.value(0).toString() + "-" +"姓名:"+query.value(1).toString() + "-" +"年龄:"+query.value(2).toString() + "-"+"性别:"+query.value(3).toString() + "-"+"部门:"+query.value(4).toString() + "-"+"职位:"+query.value(5).toString() + "-"+"简述:"+query.value(6).toString() + ";";

            QByteArray bytes = temp.toUtf8();
            clientConnection->write(bytes);
        }
    }
    else if (str[0] == '$')///代表用户进行修改操作
    {
        str = str.right(str.size()-1);
        QSqlQuery query;
        qDebug() << str;

        QStringList all = str.split(',');
         QString temp1 = "select * from employees where em_id=" + all[0] + " and em_name=" + all[1] + ";";
         query.exec(temp1);
         if (query.next()==false)
         {
            clientConnection->write("no_user!");
            return;
         }



        if (all[2] != "''")
        {
            all[2] = "em_id=" + all[2];
        }
        if (all[3] != "''")
        {
            all[3] = "em_name=" + all[3];
        }
        if (all[4] != "''")
        {
            all[4] = "em_age=" + all[4];
        }
        if (all[5] != "''")
        {
            all[5] = "em_sex=" + all[5];
        }
        if (all[6] != "''")
        {
            QString temp2 = "select * from department where dp_name=" + all[6] + ";";
            qDebug() << temp2;
            query.exec(temp2);
            if (query.next()==false)
            {
               clientConnection->write("no_dp!");
               return;
            }
            else
            {
                QString a = query.value(0).toString();
                all[6] = "dp_id=" + a;
            }
        }
        if (all[7] != "''")
        {
            QString temp3 = "select * from position where po_name=" + all[7] + ";";
            qDebug() << temp3;
            query.exec(temp3);
            if (query.next()==false)
            {
               clientConnection->write("no_po!");
               return;
            }
            else
            {
               QString a = query.value(0).toString();
               all[7] = "po_id=" + a;
            }
        }
        if (all[8] != "''")
        {
            all[8] = "em_info=" + all[8];
        }
        int i = 2;
        QString q="";
        for (i = 2; i <=8; i++)
        {
            if (all[i] != "''")
            {
                q = q + all[i] + ",";
            }
        }
        q = q.left(q.size()-1);
        q = "update employees set " + q + " where em_id=" + all[0] + " and em_name=" + all[1] + ";";
        qDebug() << q;
        if (query.exec(q) == true)
        {
            clientConnection->write("yes!");
        }
        else
        {
            clientConnection->write("no!");
        }
    }


}
void MainWindow::read_data1()
{
    if (flag == 1)
    {
        return ;
    }
    QString str;
    QByteArray buffer = clientConnection->readAll();
    str.prepend(buffer);
    int position = str.indexOf('~');
    QString left = str.left(position);
    QString right = str.right(str.size()-left.size()-1);
    str = "select* from admin " + QString("where") + " acount='" + left +QString("'") + " and passwd='" + right+QString("';");
    qDebug() << str;
    QSqlQuery query;
    query.exec(str);
    if(query.next() == true)
    {
        clientConnection->write("yes!");

        flag = 1;
        //qDebug() << "yes!" << "flag=" << flag;
    }
    else
    {
        //qDebug() << "no!";
        clientConnection->write("no!");
    }

}
