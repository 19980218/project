<?php
$conn= @mysql_connect('localhost','root','');

if($conn)
{
}	
else
{
	echo "<script>if(confirm('连接失败')) </script>";
	echo "<script>location='sign-in.php'</script>";

}

if(mysql_select_db('student_project', $conn))
{
}	
else
    echo "<script>confirm('选择数据库失败')</script>";

    
$sql = "set names utf8";
@mysql_query($sql);
$user = $_POST['user4'];
$pr_name = $_POST['pr_name4'];  
if (isset($_POST['identity2']))
{
     $identity = $_POST['identity2'];
    // echo $identity;
    if ($identity == 2)
    {
        $sql = "select * from teacher where tc_no='$user' and tc_name = '$pr_name';";
        $result = mysql_query($sql);
        if (mysql_num_rows($result) < 1)
        {
            echo "<script>(confirm('没有与该用户')) </script>";
   
	        echo "<script>location='user_operate.php'</script>";
        }
        else
        {
            $sql = "delete from teacher where tc_no='$user' and tc_name = '$pr_name';";
           // echo $sql;
            if (mysql_query($sql))
            {
                echo "<script>(confirm('删除成功')) </script>";
   
	        echo "<script>location='user_operate.php'</script>";
            }
            else
            {
                echo "<script>(confirm('删除失败')) </script>";
   
	           echo "<script>location='user_operate.php'</script>";
            }
        }
    }
    else
    {
        $sql = "select * from student where st_no='$user' and st_name = '$pr_name';";
        //echo $sql;
        $result = mysql_query($sql);
        if (mysql_num_rows($result) < 1)
        {
            echo "<script>(confirm('没有与该用户')) </script>";
   
	        echo "<script>location='user_operate.php'</script>";
        }
        else
        {
            $sql = "delete from student where st_no='$user' and st_name = '$pr_name';";
            if (mysql_query($sql))
            {
                echo "<script>(confirm('删除成功')) </script>";
   
	        echo "<script>location='user_operate.php'</script>";
            }
            else
            {
                echo "<script>(confirm('删除失败')) </script>";
   
	           echo "<script>location='user_operate.php'</script>";
            }
        }
    }
    
}
else
{
     echo "<script>(confirm('请选择用户的身份')) </script>";
   
	echo "<script>location='user_operate.php'</script>";
}
mysql_close();

?>