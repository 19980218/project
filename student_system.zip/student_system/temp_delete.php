<?php

$conn= @mysql_connect('localhost','root','');

if($conn)
{
}	
else
{
	echo "<script>if(confirm('连接失败')) </script>";
	echo "<script>location='sign-in.php'</script>";

}

if(mysql_select_db('student_project', $conn))
{
}	
else
    echo "<script>confirm('选择数据库失败')</script>";

    
$sql = "set names utf8";
@mysql_query($sql);

$pr_id = $_POST['pr_id8'];
$pr_name = $_POST['pr_name8'];
$sql = "select * from project where pr_name = '$pr_name' and pr_id = '$pr_id';";
$result = mysql_query($sql);
if (mysql_num_rows($result) < 1)
{
     echo "<script>(confirm('该项目不存在')) </script>";
   
	echo "<script>location='delete.php'</script>";
}
else
{
    $sql = "delete from project where pr_name = '$pr_name' and pr_id = '$pr_id';";
    if (mysql_query($sql))
    {
        echo "<script>(confirm('项目删除成功')) </script>";
   
	   echo "<script>location='delete.php'</script>";
    }
    else
    {
        echo "<script>(confirm('项目删除失败')) </script>";
   
	   echo "<script>location='delete.php'</script>";
    }
}



?>