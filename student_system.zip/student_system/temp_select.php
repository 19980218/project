<?php

$conn= @mysql_connect('localhost','root','');

if($conn)
{
}	
else
{
	echo "<script>if(confirm('连接失败')) ";
	echo "<script>location='sign-in.php'</script>";

}

if(mysql_select_db('student_project', $conn))
{
}	
else
    echo "<script>confirm('选择数据库失败')</script>";
  
session_start();
$pr_id = $_POST['pr_id2'];
$pr_name = $_POST['pr_name2'];
$user = $_SESSION['user'];
$sql = "set names utf8";
@mysql_query($sql);
$sql = "select project.pr_name ,grade.grade from project, user, grade where grade.user = '$user' and grade.pr_id = project.pr_id and '$pr_id'=grade.pr_id and '$pr_name'=project.pr_name; ";
//echo $sql;
$result = mysql_query($sql);
if (mysql_num_rows($result) < 1)
{
    echo "<script>confirm('没有此条记录！')</script>";
     echo "<script>location='help.php'</script>";
}
else
{
    $row = mysql_fetch_row($result);
    $pr_name = $row[0];
    $grade = $row[1];
    echo "<script>confirm('$pr_name:$grade')</script>";
    echo "<script>location='help.php'</script>";
}


?>