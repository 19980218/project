<?php
$conn= @mysql_connect('localhost','root','');

if($conn)
{
}	
else
{
	echo "<script>if(confirm('连接失败')) </script>";
	echo "<script>location='sign-in.php'</script>";

}

if(mysql_select_db('student_project', $conn))
{
}	
else
    echo "<script>confirm('选择数据库失败')</script>";
  
session_start();
$user = $_POST['user'];
$pw = $_POST['pw'];  

if (isset($_POST['identity']))
{
    $identity = $_POST['identity'];
    //echo $identity;
    //echo "<script>(confirm('等一下')) </script>";
    if ($identity == 1)
    {
        $sql = "select * from student where student.st_no = '$user' and student.st_password = '$pw'";
        $result = mysql_query($sql);
        
        
        if (mysql_num_rows($result) < 1)
        {
            echo "<script>confirm('没有该学生')</script>";
             echo "<script>location='sign-in.php'</script>";
        }
        else 
        {
            echo "<script>confirm('有该学生')</script>";
            $row = mysql_fetch_row($result);
             //print_r($row);
             unset($_SESSION['user']);
            $_SESSION['user'] = $row[1];
            echo "<script>location='index.php'</script>";
        }
        mysql_close();
    }
    else if ($identity == 2)
    {
        $sql = "select tc_no from teacher where tc_no = '$user' and tc_password='$pw';";
       // echo $sql;
         $result = mysql_query($sql);
        if (mysql_num_rows($result) < 1)
        {
            echo "<script>confirm('没有该老师')</script>";
             echo "<script>location='sign-in.php'</script>";
        }
        else 
        {
            echo "<script>confirm('有该老师')</script>";
            $row = mysql_fetch_row($result);
             //print_r($row);
             unset($_SESSION['user']);
            $_SESSION['user'] = $row[0];
            echo "<script>location='index_teacher.php'</script>";
        }
        mysql_close();
    }
    else
    {
        $sql = "select ad_name from admin where ad_name = '$user' and ad_password = '$pw';";
        $result = mysql_query($sql);
        if (mysql_num_rows($result) < 1)
        {
            echo "<script>confirm('管理员信息错误')</script>";
             echo "<script>location='sign-in.php'</script>";
        }
        else 
        {
            echo "<script>confirm('有该管理员')</script>";
            $row = mysql_fetch_row($result);
             //print_r($row);
             unset($_SESSION['user']);
            $_SESSION['user'] = $row[0];
            echo "<script>location='admin.php'</script>";
        }
        mysql_close();
    }
        
}
else
{
    echo "<script>(confirm('请选择你的身份')) </script>";
   
	echo "<script>location='sign-in.php'</script>";
}
	
?>