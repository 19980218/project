<?php

$conn= @mysql_connect('localhost','root','');

if($conn)
{
}	
else
{
	echo "<script>if(confirm('连接失败')) </script>";
	echo "<script>location='sign-in.php'</script>";

}

if(mysql_select_db('student_project', $conn))
{
}	
else
    echo "<script>confirm('选择数据库失败')</script>";

    
$sql = "set names utf8";
@mysql_query($sql);
$user = $_POST['user6'];
$pr_name = $_POST['name6'];
$pw = $_POST['pw6'];
$sex = $_POST['sex6'];  

$user2 = $_POST['user7'];
if (isset($_POST['identity4']))
{
     $identity = $_POST['identity4'];
     //echo $identity;
    if ($identity == 2)
    {
        $sql = "select * from teacher where tc_no='$user2' ;";
        $result = mysql_query($sql);
        if (mysql_num_rows($result) < 1)
        {
            echo "<script>(confirm('没有该用户')) </script>";
   
	        echo "<script>location='temp_update.php'</script>";
        }
        else
        {
            $sql = "update teacher set tc_no = '$user',tc_name='$pr_name',tc_password='$pw',tc_sex='$sex' where tc_no = '$user2';";
            //echo $sql;
            if (mysql_query($sql))
            {
                echo "<script>(confirm('修改成功')) </script>";
   
	         echo "<script>location='temp_update.php'</script>";
            }
            else
            {
                echo "<script>(confirm('修改成功')) </script>";
   
	           echo "<script>location='temp_update.php'</script>";
            }
        }
    }
    else
    {
        $sql = "select * from student where st_no='$user2' ;";
        //echo $sql;
        $result = mysql_query($sql);
        if (mysql_num_rows($result) < 1)
        {
            echo "<script>(confirm('没有该用户')) </script>";
   
	        echo "<script>location='temp_update.php'</script>";
        }
        else
        {
            $sql = "update student set st_no = '$user',st_name='$pr_name',st_password='$pw',st_sex='$sex ' where st_no = '$user2';";
            //echo $sql;
            if (mysql_query($sql))
            {
                echo "<script>(confirm('修改成功')) </script>";
   
	        echo "<script>location='temp_update.php'</script>";
            }
            else
            {
                echo "<script>(confirm('修改成功')) </script>";
   
	           echo "<script>location='temp_update.php'</script>";
            }
        }
    }
    
}
else
{
     echo "<script>(confirm('请选择用户的身份')) </script>";
   
	echo "<script>location='temp_update.php'</script>";
}


?>